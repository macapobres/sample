<?php
namespace Serbo\Store\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class UpgradeSchema implements UpgradeSchemaInterface
{

    /**
     * {@inheritdoc}
     */
    public function upgrade(
        SchemaSetupInterface $setup,
        ModuleContextInterface $context
    ) {
        $installer = $setup;

        $installer->startSetup();

        if (version_compare($context->getVersion(), '1.0.2', '<')) {
          $installer->getConnection()->addColumn(
                $installer->getTable('quote_item'),
                'name_tag_option',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'nullable' => true,
                    'comment' => 'name_tag_option'
                ]
            );
            $installer->getConnection()->addColumn(
                $installer->getTable('quote_item'),
                'name_tag_title',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'nullable' => true,
                    'comment' => 'name_tag_title'
                ]
            );
            $installer->getConnection()->addColumn(
                $installer->getTable('quote_item'),
                'name_tag_sender',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'nullable' => true,
                    'comment' => 'name_tag_sender'
                ]
            );

            $installer->getConnection()->addColumn(
                $installer->getTable('sales_order_item'),
                'name_tag_option',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'nullable' => true,
                    'comment' => 'name_tag_option'
                ]
            );
            $installer->getConnection()->addColumn(
                $installer->getTable('sales_order_item'),
                'name_tag_title',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'nullable' => true,
                    'comment' => 'name_tag_title'
                ]
            );
            $installer->getConnection()->addColumn(
                $installer->getTable('sales_order_item'),
                'name_tag_sender',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                    'nullable' => true,
                    'comment' => 'name_tag_sender'
                ]
            );
        }
        $installer->endSetup();
    }
}