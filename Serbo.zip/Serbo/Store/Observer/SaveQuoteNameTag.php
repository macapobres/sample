<?php

namespace Serbo\Store\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;

class SaveQuoteNameTag implements ObserverInterface
{

    protected $_request;

    /**
     * @param RequestInterface $request
     */
    public function __construct(RequestInterface $request){
            $this->_request = $request;
    }

    /**
     * @param EventObserver $observer
     * @return void
     */
    public function execute(EventObserver $observer)
    {
        /* @var \Magento\Quote\Model\Quote\Item $item */
        $item = $observer->getQuoteItem();

        $originalPrice = $item->getProduct()->getFinalPrice();
        $name_tag_option = $this->_request->getParam('name_tag_option');
        $name_tag_title = $this->_request->getParam('name_tag_title');
        $name_tag_sender = $this->_request->getParam('name_tag_sender');

        $item->setNameTagOption($name_tag_option);
        $item->setNameTagTitle($name_tag_title);
        $item->setNameTagSender($name_tag_sender);

       

        $item = $observer->getEvent()->getData('quote_item');
        $item = ( $item->getParentItem() ? $item->getParentItem() : $item );
        $price = $originalPrice + 500; //set your price here
        $item->setCustomPrice($price);
        $item->setOriginalCustomPrice($price);
        $item->getProduct()->setIsSuperMode(true);

    }
}