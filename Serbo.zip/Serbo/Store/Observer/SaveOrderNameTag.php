<?php

namespace Serbo\Store\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;

class SaveOrderNameTag implements ObserverInterface
{

    protected $_request;
    protected $cart;

    /**
     * @param RequestInterface $request
     */
    public function __construct(RequestInterface $request, \Magento\Checkout\Model\Cart $cart){
            $this->_request = $request;
            $this->cart = $cart;
    }

    /**
     * @param EventObserver $observer
     * @return void
     */
    public function execute(EventObserver $observer)
    {
        
        $orders = $observer->getOrder()->getAllVisibleItems();

        $quoteItems = $this->cart->getQuote()->getAllVisibleItems();

        $tagDetails = array();
        foreach( $quoteItems as $item){
            $tagDetails[] = array(
                'id'    => $item->getId(),
                'name_tag_option' => $item->getNameTagOption(),
                'name_tag_title'  =>  $item->getNameTagTilte(),
                'name_tag_sender' =>  $item->getNameTagSender()
            );
        }

        foreach($orders as $order){
            $order->setNameTagOption($this->getValue($order->getQuoteItemId(),  $tagDetails, 'name_tag_option'));
            $order->setNameTagOption($this->getValue($order->getQuoteItemId(),  $tagDetails, 'name_tag_title'));
            $order->setNameTagOption($this->getValue($order->getQuoteItemId(),  $tagDetails, 'name_tag_sender'));
            $order->save();
        }
    }
    
    function getValue($id,  $tagDetails, $index){
        foreach($tagDetails as $tag){
            if($id == $tag['id']){
                return $tag[$index];
            }
        }
        return null;
    }
}